var class_add_expr =
[
    [ "AddExpr", "class_add_expr.html#a42e626ebbd6f085cf57e6cd40028cb8c", null ],
    [ "equals", "class_add_expr.html#a806866c1e87fd065ac8374fa86979d9b", null ],
    [ "has_variable", "class_add_expr.html#a90efb4683399206101463e8cefd6e967", null ],
    [ "interp", "class_add_expr.html#a05dc1cb4091801233c41ea2aca311838", null ],
    [ "pretty_print", "class_add_expr.html#a72e0700f4ccee397fa52b4403b005b0d", null ],
    [ "printExp", "class_add_expr.html#a6d9641516e77aa47ff45941978a8a0f2", null ],
    [ "subst", "class_add_expr.html#a5c34f4b67330a0ced7b7eb772932e0ac", null ]
];