
#ifndef parse_hpp
#include "expr.h"
#define parse_hpp

#include <stdio.h>

#endif

Expr *parse_num(std::istream &in);
// parse_expr
// void whitespace