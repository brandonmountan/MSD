var class_var_expr =
[
    [ "VarExpr", "class_var_expr.html#a0312fbfa49477062d3b4ef97a925fe47", null ],
    [ "equals", "class_var_expr.html#a67f0303bb59f73fb989f0f013a719a03", null ],
    [ "has_variable", "class_var_expr.html#a133fe646e53039829a89ad73dad88ef6", null ],
    [ "interp", "class_var_expr.html#aaa180a72599f869c4f0081a36f421c71", null ],
    [ "pretty_print", "class_var_expr.html#a9c498ac0acf5656cd9d4765cb33c2e69", null ],
    [ "printExp", "class_var_expr.html#a7ae0b7e26ffcfb5cd4dd2687831fce3f", null ],
    [ "subst", "class_var_expr.html#ad649ba47f3368aff89778193937b0bcb", null ]
];