#include <iostream>
#include "cmdline.h"

int main(int argc, char** argv) {
    use_arguments(argc, argv);
    return 0;
}
// TIP See CLion help at <a
// href="https://www.jetbrains.com/help/clion/">jetbrains.com/help/clion/</a>.
//  Also, you can try interactive lessons for CLion by selecting
//  'Help | Learn IDE Features' from the main menu.