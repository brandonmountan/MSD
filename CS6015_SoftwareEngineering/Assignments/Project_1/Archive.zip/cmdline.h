//
// Created by Brandon Mountan on 1/13/25.
//

#ifndef CMDLINE_H
#define CMDLINE_H

void use_arguments(int argc, char *argv[]);

#endif //CMDLINE_H
