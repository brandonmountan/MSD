var searchData=
[
  ['varexpr_0',['VarExpr',['../class_var_expr.html',1,'']]],
  ['void_5ftype_1',['void_type',['../struct_catch_1_1detail_1_1void__type.html',1,'Catch::detail']]]
];
