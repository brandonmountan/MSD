var searchData=
[
  ['nameandtags_0',['NameAndTags',['../struct_catch_1_1_name_and_tags.html',1,'Catch']]],
  ['noncopyable_1',['NonCopyable',['../class_catch_1_1_non_copyable.html',1,'Catch']]],
  ['numexpr_2',['NumExpr',['../class_num_expr.html',1,'']]]
];
