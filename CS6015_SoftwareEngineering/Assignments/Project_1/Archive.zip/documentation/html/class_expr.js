var class_expr =
[
    [ "equals", "class_expr.html#a3ca7c707e94e443eecd9f1611d882da4", null ],
    [ "has_variable", "class_expr.html#a92dc26078993a4b9721ea732274a435c", null ],
    [ "interp", "class_expr.html#aeba8585d8225419d49166371306542c1", null ],
    [ "pretty_print", "class_expr.html#a02a3a4230ed4972345fbbb60381af8cd", null ],
    [ "printExp", "class_expr.html#addcf135f59a05b0912ba72aa65d82f45", null ],
    [ "subst", "class_expr.html#af13bf7824daf6cee0d5f4de0475a9767", null ],
    [ "to_pretty_string", "class_expr.html#a6ad7c18234f22d96d6917089b5bd7caa", null ],
    [ "to_string", "class_expr.html#abe130f37bd185ec13c5113de16fc7bf7", null ]
];