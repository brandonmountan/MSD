var searchData=
[
  ['has_5fvariable_0',['has_variable',['../class_expr.html#a92dc26078993a4b9721ea732274a435c',1,'Expr::has_variable()'],['../class_num_expr.html#a688fa97c58c339c17378c803cddc14ea',1,'NumExpr::has_variable()'],['../class_add_expr.html#a90efb4683399206101463e8cefd6e967',1,'AddExpr::has_variable()'],['../class_mult_expr.html#a6ec2543c4976721e5dbf9f6ddbdc0c3c',1,'MultExpr::has_variable()'],['../class_var_expr.html#a133fe646e53039829a89ad73dad88ef6',1,'VarExpr::has_variable()']]]
];
